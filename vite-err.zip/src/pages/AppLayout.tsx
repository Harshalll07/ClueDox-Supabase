import { ReactNode, useState } from "react";
import { Menu } from "lucide-react";
import Sidebar from "./Sidebar";
import { useIsMobile } from "@/hooks/use-mobile";
import BottomNavBar from "@/components/ui/bottom-nav-bar";
import { SupportChat } from "@/components/SupportChat";
import { NotificationBell } from "@/components/NotificationBell";
import { cn } from "@/lib/utils";

const AppLayout = ({ children }: { children: ReactNode }) => {
  const isMobile = useIsMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <div className="flex h-screen w-full bg-[#F7F7F5] overflow-hidden">

      {/* DESKTOP SIDEBAR */}
      {!isMobile && (
        <div
          className={cn(
            "fixed top-0 left-0 h-screen z-50 bg-white",
            "border-r border-gray-300 shadow-[2px_0_10px_rgba(0,0,0,0.06)]",
            "transition-all duration-300 ease-in-out",
            sidebarCollapsed ? "w-16" : "w-64"
          )}
        >
          <Sidebar collapsed={sidebarCollapsed} />
        </div>
      )}

      {/* MOBILE OVERLAY */}
      {isMobile && sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* MOBILE SIDEBAR */}
      {isMobile && (
        <div
          className={cn(
            "fixed inset-y-0 left-0 z-40 w-64 bg-white transition-transform duration-300",
            sidebarOpen ? "translate-x-0" : "-translate-x-full"
          )}
        >
          <Sidebar onClose={() => setSidebarOpen(false)} />
        </div>
      )}

      {/* MAIN CONTENT */}
      <main
        className={cn(
          " flex flex-col overflow-hidden transition-all duration-300",
          !isMobile && (sidebarCollapsed ? "ml-16" : "ml-64")
        )}
      >

        {/* TOPBAR */}
        <div className="h-14 flex items-center justify-between px-4 border-b bg-white">
          <button
            onClick={() => {
              if (isMobile) {
                setSidebarOpen(true);
              } else {
                setSidebarCollapsed((prev) => !prev);
              }
            }}
            className="p-2 rounded-lg hover:bg-gray-100"
          >
            <Menu className="w-5 h-5" />
          </button>

          <NotificationBell />
        </div>

        {/* PAGE CONTENT */}
        <div className=" overflow-y-auto">
          {children}
        </div>
      </main>

      {isMobile && <BottomNavBar />}
      <SupportChat />
    </div>
  );
};

export default AppLayout;