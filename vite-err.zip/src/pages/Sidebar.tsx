import { NavLink as RouterNavLink, useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  LayoutDashboard,
  Upload,
  FolderOpen,
  Search,
  MessageCircle,
  FolderTree,
  ArrowLeftRight,
  Bell,
  BarChart3,
  Globe,
  HardDrive,
  Smartphone,
  Settings,
  LogOut,
  Moon,
  Sun,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useTheme } from "@/hooks/useTheme";

type SidebarProps = {
  collapsed?: boolean;
  onClose?: () => void;
};

const navItems = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/upload", icon: Upload, label: "Upload" },
  { to: "/files", icon: FolderOpen, label: "Files" },
  { to: "/search", icon: Search, label: "Search" },
  { to: "/chat", icon: MessageCircle, label: "AI Chat" },
  { to: "/smart-folders", icon: FolderTree, label: "Smart Folders" },
  { to: "/compare", icon: ArrowLeftRight, label: "Compare" },
  { to: "/reminders", icon: Bell, label: "Reminders" },
  { to: "/analytics", icon: BarChart3, label: "Analytics" },
  { to: "/community", icon: Globe, label: "Community" },
  { to: "/google-drive", icon: HardDrive, label: "Google Drive" },
  { to: "/whatsapp", icon: Smartphone, label: "WhatsApp" },
];

const Sidebar = ({ collapsed = false, onClose }: SidebarProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { isDark, toggleTheme } = useTheme();
  const [openDropdown, setOpenDropdown] = useState(false);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out");
    navigate("/");
  };

  return (
    <aside className="h-full flex flex-col bg-white transition-all duration-300 overflow-visible">
      {/* LOGO */}
      <div
        className={cn(
          "flex items-center px-3 py-3 border-b border-gray-100",
          collapsed ? "justify-center" : "gap-2"
        )}
      >
        <HardDrive className="w-5 h-5 text-indigo-600" />
        {!collapsed && <span className="font-bold text-lg text-gray-900">Cluedox</span>}
      </div>

      {/* WORKSPACE */}
      {!collapsed && (
        <div className="px-4 py-3 text-[10px] font-semibold uppercase tracking-wider text-gray-500">
          Workspace
        </div>
      )}

      {/* NAV */}
      <nav className="flex-1 px-2 py-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.to;

          return (
            <RouterNavLink
              key={item.to}
              to={item.to}
              onClick={onClose}
              title={collapsed ? item.label : ""}
              className={cn(
                "flex items-center rounded-lg transition-all duration-300 group",
                collapsed ? "justify-center py-3" : "gap-2 px-3 py-2",
                isActive
                  ? "bg-gray-100 font-medium text-gray-900"
                  : "hover:bg-gray-50 text-gray-600"
              )}
            >
              <Icon
                className={cn(
                  "w-5 h-5",
                  isActive ? "text-indigo-600" : "text-gray-500 group-hover:text-gray-900",
                  collapsed ? "mx-auto" : ""
                )}
                strokeWidth={1.5}
              />

              {!collapsed && <span className="text-sm">{item.label}</span>}
            </RouterNavLink>
          );
        })}
      </nav>

      {/* BOTTOM */}
      <div className="relative border-t border-gray-100 p-3 z-50">
        {/* DROPDOWN MENU */}
        {openDropdown && !collapsed && (
          <div className="absolute bottom-full left-2 right-2 mb-2 bg-white border border-gray-200 rounded-xl shadow-lg p-2 space-y-1 z-50">
            {/* USER NAME */}
            <div className="px-3 py-2 text-sm font-medium text-gray-900 border-b border-gray-100 mb-1">
              User
            </div>

            {/* SETTINGS */}
            <button
              onClick={() => {
                navigate("/settings");
                setOpenDropdown(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 text-sm text-gray-700 transition-colors"
            >
              Settings
            </button>

            {/* DARK MODE */}
            <button
              onClick={() => {
                toggleTheme();
                setOpenDropdown(false);
              }}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-gray-100 text-sm text-gray-700 transition-colors"
            >
              {isDark ? "Light Mode" : "Dark Mode"}
            </button>

            {/* LOGOUT */}
            <button
              onClick={handleSignOut}
              className="w-full text-left px-3 py-2 rounded-lg hover:bg-red-50 text-sm text-red-600 transition-colors"
            >
              Logout
            </button>
          </div>
        )}

        {/* USER BAR */}
        <div
          onClick={() => setOpenDropdown(!openDropdown)}
          className="relative z-50 flex items-center justify-between cursor-pointer rounded-lg p-2 hover:bg-gray-100 transition-colors"
        >
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-md bg-indigo-600 text-white flex items-center justify-center font-medium">
              U
            </div>

            {!collapsed && (
              <div>
                <p className="text-sm font-medium text-gray-900 leading-none mb-1">User</p>
                <p className="text-xs text-gray-500 leading-none">Cluedox Plan</p>
              </div>
            )}
          </div>

          {!collapsed && (
            <span
              className="text-gray-400 text-xs transition-transform duration-200"
              style={{ transform: openDropdown ? "rotate(180deg)" : "rotate(0deg)" }}
            >
              ⌃
            </span>
          )}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
